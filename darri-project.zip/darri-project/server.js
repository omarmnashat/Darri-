const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = 'your-secret-key-here';

// middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// connection pool
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'darri_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// إنشاء الجداول
async function createTables() {
    try {
        const connection = await pool.getConnection();
        
        // جدول المستخدمين
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                phone VARCHAR(20),
                national_id VARCHAR(20),
                role ENUM('tenant', 'owner', 'payment', 'maintenance', 'admin') NOT NULL,
                status ENUM('active', 'inactive', 'pending') DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        `);

        // جدول العقارات
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS properties (
                id INT AUTO_INCREMENT PRIMARY KEY,
                owner_id INT NOT NULL,
                name VARCHAR(255) NOT NULL,
                type ENUM('villa', 'apartment', 'building', 'compound') NOT NULL,
                address TEXT NOT NULL,
                city VARCHAR(100) NOT NULL,
                units INT NOT NULL,
                monthly_rent DECIMAL(10,2) NOT NULL,
                description TEXT,
                status ENUM('active', 'inactive') DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (owner_id) REFERENCES users(id)
            )
        `);

        // جدول العقود
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS contracts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                property_id INT NOT NULL,
                tenant_id INT NOT NULL,
                start_date DATE NOT NULL,
                end_date DATE NOT NULL,
                monthly_rent DECIMAL(10,2) NOT NULL,
                status ENUM('active', 'expired', 'terminated') DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (property_id) REFERENCES properties(id),
                FOREIGN KEY (tenant_id) REFERENCES users(id)
            )
        `);

        // جدول طلبات الصيانة
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS maintenance_requests (
                id INT AUTO_INCREMENT PRIMARY KEY,
                contract_id INT NOT NULL,
                type VARCHAR(100) NOT NULL,
                description TEXT NOT NULL,
                priority ENUM('urgent', 'high', 'medium', 'low') DEFAULT 'medium',
                status ENUM('pending', 'approved', 'in_progress', 'completed', 'cancelled') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (contract_id) REFERENCES contracts(id)
            )
        `);

        // جدول الفواتير
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS invoices (
                id INT AUTO_INCREMENT PRIMARY KEY,
                contract_id INT NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                due_date DATE NOT NULL,
                status ENUM('pending', 'paid', 'overdue') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (contract_id) REFERENCES contracts(id)
            )
        `);

        // جدول المدفوعات
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS payments (
                id INT AUTO_INCREMENT PRIMARY KEY,
                invoice_id INT NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                payment_method VARCHAR(50) NOT NULL,
                status ENUM('pending', 'confirmed', 'failed') DEFAULT 'pending',
                payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (invoice_id) REFERENCES invoices(id)
            )
        `);

        // جدول الإشعارات
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS notifications (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                title VARCHAR(255) NOT NULL,
                message TEXT NOT NULL,
                type VARCHAR(50) NOT NULL,
                is_read BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        `);

        connection.release();
        console.log('✅ تم إنشاء الجداول بنجاح');
    } catch (error) {
        console.error('❌ خطأ في إنشاء الجداول:', error);
    }
}

// middleware المصادقة
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'رمز الوصول مطلوب' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'رمز وصول غير صالح' });
        }
        req.user = user;
        next();
    });
};

// المسارات

// التسجيل
app.post('/api/register', async (req, res) => {
    try {
        const { name, email, password, phone, national_id, role } = req.body;

        // التحقق من البيانات
        if (!name || !email || !password || !role) {
            return res.status(400).json({ error: 'جميع الحقول مطلوبة' });
        }

        // تشفير كلمة المرور
        const hashedPassword = await bcrypt.hash(password, 10);

        const connection = await pool.getConnection();
        
        // إضافة المستخدم
        const [result] = await connection.execute(
            'INSERT INTO users (name, email, password, phone, national_id, role) VALUES (?, ?, ?, ?, ?, ?)',
            [name, email, hashedPassword, phone, national_id, role]
        );

        // إنشاء توكن
        const token = jwt.sign(
            { userId: result.insertId, email, role },
            JWT_SECRET,
            { expiresIn: '24h' }
        );

        connection.release();

        res.json({
            message: 'تم إنشاء الحساب بنجاح',
            token,
            user: {
                id: result.insertId,
                name,
                email,
                role
            }
        });

    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            res.status(400).json({ error: 'البريد الإلكتروني مسجل مسبقاً' });
        } else {
            console.error('خطأ في التسجيل:', error);
            res.status(500).json({ error: 'خطأ في الخادم' });
        }
    }
});

// تسجيل الدخول
app.post('/api/login', async (req, res) => {
    try {
        const { email, password, role } = req.body;

        const connection = await pool.getConnection();
        const [users] = await connection.execute(
            'SELECT * FROM users WHERE email = ? AND role = ?',
            [email, role]
        );

        if (users.length === 0) {
            connection.release();
            return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
        }

        const user = users[0];

        // التحقق من كلمة المرور
        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            connection.release();
            return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
        }

        // إنشاء توكن
        const token = jwt.sign(
            { userId: user.id, email: user.email, role: user.role },
            JWT_SECRET,
            { expiresIn: '24h' }
        );

        connection.release();

        res.json({
            message: 'تم تسجيل الدخول بنجاح',
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role
            }
        });

    } catch (error) {
        console.error('خطأ في تسجيل الدخول:', error);
        res.status(500).json({ error: 'خطأ في الخادم' });
    }
});

// الحصول على بيانات المستخدم
app.get('/api/user', authenticateToken, async (req, res) => {
    try {
        const connection = await pool.getConnection();
        const [users] = await connection.execute(
            'SELECT id, name, email, phone, role, status FROM users WHERE id = ?',
            [req.user.userId]
        );

        if (users.length === 0) {
            connection.release();
            return res.status(404).json({ error: 'المستخدم غير موجود' });
        }

        connection.release();
        res.json({ user: users[0] });

    } catch (error) {
        console.error('خطأ في جلب بيانات المستخدم:', error);
        res.status(500).json({ error: 'خطأ في الخادم' });
    }
});

// إضافة عقار
app.post('/api/properties', authenticateToken, async (req, res) => {
    try {
        const { name, type, address, city, units, monthly_rent, description } = req.body;

        if (req.user.role !== 'owner') {
            return res.status(403).json({ error: 'غير مصرح لك بإضافة عقارات' });
        }

        const connection = await pool.getConnection();
        const [result] = await connection.execute(
            'INSERT INTO properties (owner_id, name, type, address, city, units, monthly_rent, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [req.user.userId, name, type, address, city, units, monthly_rent, description]
        );

        connection.release();

        res.json({
            message: 'تم إضافة العقار بنجاح',
            propertyId: result.insertId
        });

    } catch (error) {
        console.error('خطأ في إضافة العقار:', error);
        res.status(500).json({ error: 'خطأ في الخادم' });
    }
});

// الحصول على عقارات المالك
app.get('/api/owner/properties', authenticateToken, async (req, res) => {
    try {
        if (req.user.role !== 'owner') {
            return res.status(403).json({ error: 'غير مصرح' });
        }

        const connection = await pool.getConnection();
        const [properties] = await connection.execute(
            'SELECT * FROM properties WHERE owner_id = ?',
            [req.user.userId]
        );

        connection.release();
        res.json({ properties });

    } catch (error) {
        console.error('خطأ في جلب العقارات:', error);
        res.status(500).json({ error: 'خطأ في الخادم' });
    }
});

// إضافة عقد
app.post('/api/contracts', authenticateToken, async (req, res) => {
    try {
        const { property_id, tenant_id, start_date, end_date, monthly_rent } = req.body;

        const connection = await pool.getConnection();
        const [result] = await connection.execute(
            'INSERT INTO contracts (property_id, tenant_id, start_date, end_date, monthly_rent) VALUES (?, ?, ?, ?, ?)',
            [property_id, tenant_id, start_date, end_date, monthly_rent]
        );

        connection.release();

        res.json({
            message: 'تم إضافة العقد بنجاح',
            contractId: result.insertId
        });

    } catch (error) {
        console.error('خطأ في إضافة العقد:', error);
        res.status(500).json({ error: 'خطأ في الخادم' });
    }
});

// إضافة طلب صيانة
app.post('/api/maintenance', authenticateToken, async (req, res) => {
    try {
        const { contract_id, type, description, priority } = req.body;

        const connection = await pool.getConnection();
        const [result] = await connection.execute(
            'INSERT INTO maintenance_requests (contract_id, type, description, priority) VALUES (?, ?, ?, ?)',
            [contract_id, type, description, priority]
        );

        connection.release();

        res.json({
            message: 'تم إرسال طلب الصيانة بنجاح',
            requestId: result.insertId
        });

    } catch (error) {
        console.error('خطأ في إضافة طلب الصيانة:', error);
        res.status(500).json({ error: 'خطأ في الخادم' });
    }
});

// الحصول على طلبات الصيانة
app.get('/api/maintenance', authenticateToken, async (req, res) => {
    try {
        const connection = await pool.getConnection();
        
        let query = `
            SELECT mr.*, p.name as property_name, u.name as tenant_name 
            FROM maintenance_requests mr
            JOIN contracts c ON mr.contract_id = c.id
            JOIN properties p ON c.property_id = p.id
            JOIN users u ON c.tenant_id = u.id
        `;

        if (req.user.role === 'tenant') {
            query += ' WHERE c.tenant_id = ?';
            var [requests] = await connection.execute(query, [req.user.userId]);
        } else if (req.user.role === 'owner') {
            query += ' WHERE p.owner_id = ?';
            var [requests] = await connection.execute(query, [req.user.userId]);
        } else {
            var [requests] = await connection.execute(query);
        }

        connection.release();
        res.json({ requests });

    } catch (error) {
        console.error('خطأ في جلب طلبات الصيانة:', error);
        res.status(500).json({ error: 'خطأ في الخادم' });
    }
});

// إضافة فاتورة
app.post('/api/invoices', authenticateToken, async (req, res) => {
    try {
        const { contract_id, amount, due_date } = req.body;

        if (req.user.role !== 'payment') {
            return res.status(403).json({ error: 'غير مصرح لك بإضافة فواتير' });
        }

        const connection = await pool.getConnection();
        const [result] = await connection.execute(
            'INSERT INTO invoices (contract_id, amount, due_date) VALUES (?, ?, ?)',
            [contract_id, amount, due_date]
        );

        connection.release();

        res.json({
            message: 'تم إضافة الفاتورة بنجاح',
            invoiceId: result.insertId
        });

    } catch (error) {
        console.error('خطأ في إضافة الفاتورة:', error);
        res.status(500).json({ error: 'خطأ في الخادم' });
    }
});

// الحصول على الإشعارات
app.get('/api/notifications', authenticateToken, async (req, res) => {
    try {
        const connection = await pool.getConnection();
        const [notifications] = await connection.execute(
            'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 10',
            [req.user.userId]
        );

        connection.release();
        res.json({ notifications });

    } catch (error) {
        console.error('خطأ في جلب الإشعارات:', error);
        res.status(500).json({ error: 'خطأ في الخادم' });
    }
});

// تحديث حالة طلب الصيانة
app.put('/api/maintenance/:id', authenticateToken, async (req, res) => {
    try {
        const { status } = req.body;
        const requestId = req.params.id;

        const connection = await pool.getConnection();
        await connection.execute(
            'UPDATE maintenance_requests SET status = ? WHERE id = ?',
            [status, requestId]
        );

        connection.release();

        res.json({ message: 'تم تحديث حالة الطلب بنجاح' });

    } catch (error) {
        console.error('خطأ في تحديث حالة الطلب:', error);
        res.status(500).json({ error: 'خطأ في الخادم' });
    }
});

// الحصول على الإحصائيات
app.get('/api/stats', authenticateToken, async (req, res) => {
    try {
        const connection = await pool.getConnection();
        let stats = {};

        if (req.user.role === 'tenant') {
            const [contracts] = await connection.execute(
                'SELECT COUNT(*) as count FROM contracts WHERE tenant_id = ? AND status = "active"',
                [req.user.userId]
            );
            const [maintenance] = await connection.execute(
                'SELECT COUNT(*) as count FROM maintenance_requests mr JOIN contracts c ON mr.contract_id = c.id WHERE c.tenant_id = ? AND mr.status = "pending"',
                [req.user.userId]
            );
            
            stats.activeContracts = contracts[0].count;
            stats.pendingMaintenance = maintenance[0].count;
            // ... إحصائيات أخرى

        } else if (req.user.role === 'owner') {
            const [properties] = await connection.execute(
                'SELECT COUNT(*) as count FROM properties WHERE owner_id = ?',
                [req.user.userId]
            );
            // ... إحصائيات أخرى
        }

        connection.release();
        res.json({ stats });

    } catch (error) {
        console.error('خطأ في جلب الإحصائيات:', error);
        res.status(500).json({ error: 'خطأ في الخادم' });
    }
});

// routes لاختبار API
app.get('/api/test', (req, res) => {
    res.json({
        success: true,
        message: '✅ الـ API شغال بنجاح!',
        timestamp: new Date().toISOString(),
        data: {
            service: 'Darri Real Estate',
            version: '1.0.0',
            status: 'active'
        }
    });
});

// route أساسي
app.get('/', (req, res) => {
    res.json({
        message: '🚀 Darri Backend Server',
        status: 'running',
        port: process.env.PORT || 3000
    });
});

// تشغيل الخادم
app.listen(PORT, async () => {
    console.log(`🚀 الخادم يعمل على http://localhost:${PORT}`);
    await createTables();
});